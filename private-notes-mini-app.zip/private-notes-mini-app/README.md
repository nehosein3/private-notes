# Private Notes — Telegram Mini App

Apple Notes-inspired personal notes Mini App.

Features:
- English UI
- Persian RTL and English LTR writing
- Auto / RTL / LTR direction control
- Search
- Create, edit and delete notes
- Local browser storage
- Telegram Mini App SDK

This first version stores notes in browser localStorage. The next step is hosting these files on HTTPS and connecting the URL to the Telegram bot through BotFather.
